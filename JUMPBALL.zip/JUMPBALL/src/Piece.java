import javax.swing.*;

public class Piece
{
    int centerx;
    int centery;
    int ray;
    public Piece(int centerx ,int centery, int ray)
    {
        this.centerx = centerx;
        this.centery = centery;
        this.ray = ray;
    }

    public void move(float speed)
    {
        this.centerx -= 1*speed;
    }
}
