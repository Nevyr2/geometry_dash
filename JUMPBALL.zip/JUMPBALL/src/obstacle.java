import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class obstacle
{
    int posx;
    int posy;
    int width;
    public obstacle(int posx, int posy, int width)
    {
        this.posx = posx;
        this.posy = posy;
        this.width = width;
    }

    public void move(float speed)
    {
        this.posx -= 1*speed;
    }

    public void touch_obstacle(Ball ball) throws IOException
    {
        if ( (ball.x + ball.width) >= posx
                && ball.x <= posx + width
                && (ball.y + ball.width) > posy
                &&  ball.y < (posy + width))
        {
            ball.alive = false;
            
            File file = new File("D:\\save_gd.txt");
        	int keep_money = 0;
            if (file.exists())
            {
            	BufferedReader br = new BufferedReader(new FileReader("D:\\save_gd.txt")); 
            
            	String st; 
            	st = br.readLine();
            	if (st == "")
            		keep_money = 0;
            	else
            		keep_money = Integer.parseInt(st);
            }

            
            String fileContent = Integer.toString(ball.money);
            FileWriter fileWriter = new FileWriter("D:\\save_gd.txt");
            fileWriter.write(fileContent);
            fileWriter.write(System.getProperty("line.separator") + String.valueOf(ball.color));
            fileWriter.close();
        }
    }
}

