import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import java.util.Random; 
import java.util.ArrayList;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.*;

import org.omg.CORBA.SystemException;

public class Ball extends JPanel implements Runnable 
{
    public int x = 50;
    public int y = 650;
    public int width = 50;
    boolean on_jump = false;
    boolean on_ground = true;
    int ground =  650;
    int jump_ground = 0;
    boolean alive = true;
    boolean quit = false;
    float speed = 1;
    int score = 0;
    int money = 0;
    int lvl = 1;
    int next_lvl = 5;
    int High_score = 0;
    obstacle on_obstacle = null;
    String color = "blue";
    int A= score;
    
    
    ArrayList<obstacle> list_obstacle = new ArrayList<obstacle>();
    ArrayList<Piece> list_piece = new ArrayList<Piece>();
    JPanel panel = new JPanel();

    public Ball(int money) throws IOException
    {  
    	this.money = money;
    	
    	File file = new File("D:\\save_gd.txt");
        if (file.exists())
        {
        	BufferedReader br = new BufferedReader(new FileReader("D:\\save_gd.txt")); 
        
        	String st; 
        	st = br.readLine();
        	st = br.readLine();
        	if (st == null)
        		color = "blue";
        	else
        	{
        		color = st;
        	}
        }
    }
    @Override
    protected void paintComponent(Graphics g) 
    {

        super.paintComponent(g);
        
        //clear everything
        g.clearRect(0,0, 2000, 2000);
    
        // print ground and line
        g.setColor(Color.BLACK);
        g.drawLine(0,700,2500,700);
        g.drawLine(0,50,2500,50);
        g.drawLine(0,165,2500,165);
        
        //print money
        g.setColor(Color.YELLOW);
        g.setFont(new Font("Arial Black", Font.BOLD, 50));
        g.drawString("MONEY: " + money + "$", 1000, 125);
        
        //print High-score
        g.setColor(Color.BLUE);
        g.setFont(new Font("Arial Black", Font.BOLD, 50));
        g.drawString("HIGH SCORE: "+ High_score, 50, 100);
        
        //print Score
        g.setColor(Color.BLUE);
        g.setFont(new Font("Arial Black", Font.BOLD, 50));
        g.drawString("SCORE: " + score,50,150);

        //print next_lvl
        g.setColor(Color.GREEN);
        g.setFont(new Font("Arial Black", Font.BOLD, 50));
        g.drawString("Next_lvl: " + (next_lvl),600,150);

        //print level
        g.setColor(Color.GREEN);
        g.setFont(new Font("Arial Black", Font.BOLD, 50));
        g.drawString("LEVEL : " + lvl,600,100);

        //print DEAD if you are
        if (!alive)
        {
            g.setColor(Color.RED);
            g.setFont(new Font("Arial Black", Font.BOLD, 50));
            g.drawString("YOU'RE DEAD",300,400);

            g.setColor(Color.GREEN);
            g.setFont(new Font("Arial Black", Font.BOLD, 20));
            g.drawString("Press Space to Try Again",50,750);
        }

        // print new position player
        if (color.equals("blue"))
        {
        	g.setColor(Color.BLUE);
        	g.fillRect(x, y, width, width);
        }
        if (color.equals("yellow"))
        {
        	g.setColor(Color.YELLOW);
        	g.fillRect(x, y, width, width);
        }
        if (color.equals("green"))
        {
        	g.setColor(Color.GREEN);
        	g.fillRect(x, y, width, width);
        }
        if (color.equals("red"))
        {
        	g.setColor(Color.RED);
        	g.fillRect(x, y, width, width);
        }
        
        // print new position obstacle
        for (int i = 0; i < list_obstacle.size(); i++)
        {
            g.setColor(Color.RED);
            obstacle o = list_obstacle.get(i);
            g.fillRect(o.posx, o.posy, o.width, o.width);
        }
        for (int j = 0; j < list_piece.size(); j++)
        {
            g.setColor(Color.YELLOW);
            Piece p = list_piece.get(j);
            //je d�finis la taille de la piece et sa position 
            g.fillOval(p.centerx,p.centery,p.ray*2,p.ray*2); // center/rayon
        }
    }

    public void update_score_lvl()
    {
        if (!alive)
        {
            score = 0;
            lvl = 1;
            next_lvl = 5;
        }

        if (next_lvl == 0)
        {
            lvl += 1;
            next_lvl = 5;
        }
    }

    public void move_player()
    {
        //on obstacle
        if (on_obstacle != null)
        {
            if ( (on_obstacle.posx + width) < x)
            {
                on_ground = false;
                ground += on_obstacle.width;
                on_obstacle = null;
            }
        }

        // if ball is jumping, go upward
        if (on_jump)
            y -= 2*speed;

        // if ball finish jump, have to go downward until touch ground
        if (!on_ground && !on_jump)
            y += 2*speed;

        // touch ground
        if (y >= ground)
            on_ground = true;
        // finish jump
        else if (y < jump_ground - 180)
            on_jump = false;

    }

    public void move_all_obstacles() throws IOException
    {
        //check if ball jump one of the obstacle
        for (int i = 0; i < list_obstacle.size(); i++)
        {
            obstacle o = list_obstacle.get(i);

            if ( Math.abs(y + width - o.posy) <= 1
                    && o.posx + o.width - x <= width + o.width
                    && !on_ground && !on_jump)
            {
                on_ground = true;
                on_jump = false;
                ground -= o.width;
                on_obstacle = o;
            }
            else
            {
                //check if alive
                o.touch_obstacle(this);
            }
            //move obstacle
            o.move(speed);
        }
        for (int i = 0; i < list_piece.size(); i++)
        {
            Piece p = list_piece.get(i);
        
        //move obstacle
            p.move(speed);
        }
    }
    public void set_high_score()
    {
    	// d�finir le high score
    	if (score > High_score)
    	{
    		High_score = score;
    	}
    }
    public void delete_money()
    {
    	//delete money passed
    	for (int i = 0; i < list_piece.size(); i++)
        {
            Piece p = list_piece.get(i);
            if (x < p.centerx + p.ray && x + width > p.centerx - p.ray
            		&& y < p.centery && y + width > p.centery)
            {
                list_piece.remove(i);
                money += 1;
            } 
        }
    }
    public void maj_obstacle()
    {
        //delete obstacle passed
        for (int i = 0; i < list_obstacle.size(); i++)
        {
            obstacle o = list_obstacle.get(i);
            if (o.posx < -50)
            {
                list_obstacle.remove(i);
                score += 1;
                next_lvl -= 1;
            }
        }

        //delete obstacle when too close
        for (int i = 0; i < list_obstacle.size(); i++)
        {
            obstacle o1 = list_obstacle.get(i);
            for (int j = 0; j < list_obstacle.size(); j++)
            {
                obstacle o2 = list_obstacle.get(j);

                if (i == j)
                    continue;

                if (Math.abs(o1.posx - o2.posx) > 20
                        && Math.abs(o1.posx - o2.posx) < 60
                        && o1.posy == o2.posy)
                    list_obstacle.remove(j);
            }
        }
        //add obstacle
        while (list_obstacle.size() < (5 + lvl))
        {
            int width = (int)(Math.random() * 20) + 10;
            obstacle new_o = new obstacle(1000 + (int)(Math.random() * 3000),
                    700 - width - ((int)(Math.random() * 2) * 60), width);
            list_obstacle.add(new_o);
        }
        //add piece
        int ray = 15;
        		
        while (list_piece.size() < 5) {
        	Piece new_p = new Piece(1000 + (int)(Math.random() * 10000),
                    700 - ray - ((int)(Math.random() * 3) * 30) - 30, ray);
        	list_piece.add(new_p);
        }
    }
    public void run() 
    {
        System.out.println("Début de la méthode run");
        while (!quit) 
        {
            Toolkit.getDefaultToolkit().sync();
            if (alive)
            {
                move_player();

                try {
					move_all_obstacles();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

                maj_obstacle();
                
                delete_money();

                update_score_lvl();
                
                set_high_score();

                // call paintComponent to print everything
                this.repaint();

                try 
                {
                    // sleep
                    Thread.sleep(3);
                } 
                catch (InterruptedException e) 
                {
                    e.printStackTrace();
                }
            }

        }
    }
}
