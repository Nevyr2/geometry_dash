import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MainFrame extends JFrame implements ActionListener
{
    private JPanel panel = new JPanel();
    private JPanel panelsud = new JPanel();
    private JPanel panelnorth = new JPanel();
    private JButton button_start = new JButton("Start");
    private JButton button_shop = new JButton("Shop");
    private JButton button_quit = new JButton("Quit");
    
	private JButton Gcolor = new JButton("Green 100$");
	private JButton Ycolor = new JButton("Yellow 200$");
	private JButton Rcolor = new JButton("Red 300$");

    Ball ball;
    public static boolean game = false;
    public static boolean shop = false;
    public static MainFrame mainFrame;
    
    public MainFrame() throws IOException 
    {
    	if (!game && !shop)
    	{
    		this.setVisible(true);
			this.setTitle("Geometry Dash");
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			panel.setLayout(new BorderLayout());
			panelsud.setLayout(new BorderLayout());
			panel.add(panelsud, BorderLayout.SOUTH);
			panelnorth.setLayout(new BorderLayout());
			panel.add(panelnorth, BorderLayout.CENTER);
			
			JLabel image = new JLabel( new ImageIcon( "D:\\JUMPBALL\\bin\\jeux_java.png"));
			panelnorth.add(image, BorderLayout.CENTER);
			panelsud.add(button_start, BorderLayout.CENTER);
			button_start.addActionListener(this);
			panelsud.add(button_shop, BorderLayout.WEST);
			button_shop.addActionListener(this);
			panelsud.add(button_quit, BorderLayout.EAST);
			button_quit.addActionListener(this);
			panel.setBackground(Color.white);
			this.setContentPane(panel);
			this.setSize(400, 400);
			this.setLocationRelativeTo(null);
			panel.updateUI();
    	}
    	else if (game)	
    	{	
    		File file = new File("D:\\save_gd.txt");
        	int keep_money = 0;
            if (file.exists())
            {
            	BufferedReader br = new BufferedReader(new FileReader("D:\\save_gd.txt")); 
            
            	String st; 
            	st = br.readLine();
            	if (st == "")
            		keep_money = 0;
            	else
            		keep_money = Integer.parseInt(st);
            }
            
        	ball = new Ball(keep_money);
    		this.setVisible(true);
        	this.setTitle("Game");
        	this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        	panel.setLayout(new BorderLayout());
        	panelsud.setLayout(new BorderLayout());
        	panel.add(panelsud, BorderLayout.SOUTH);
        	this.setBackground(Color.WHITE);
        	this.addKeyListener(new KeyListener() {

            	@Override
            	public void keyTyped(KeyEvent e) {
            	}


            	@Override
            	public void keyReleased(KeyEvent e) {
                	int keyCode = e.getKeyCode();
                	if (keyCode == 32) {
                    	panel.updateUI();
                	}
            	}

            	@Override
            	public void keyPressed(KeyEvent e) 
            	{
                	int keyCode = e.getKeyCode();
                	if (keyCode == 32) 
                	{
                    	//launch again
                    	if (!ball.alive)
                    	{
                    		ball.x = 50;
                            ball.y = 648;
                            ball.list_obstacle.clear();
                            ball.ground = 650;
                            ball.alive = true;
                            panel.updateUI();
                    	}

                    	// able to jump only if on ground
                    	else if (ball.on_ground)
                    	{
                        	ball.on_jump = true;
                        	ball.on_ground = false;
                        	panel.updateUI();
                        	ball.jump_ground = ball.y;
                    	}

                	}
            	}
        	});

        	this.setContentPane(panel);
        	this.setSize(1600, 1000);
        	this.setLocationRelativeTo(null);

        	panel.add(ball, BorderLayout.CENTER);
        	Thread thread = new Thread(ball);
        	thread.start();
        	panel.updateUI();
    	}	
    	else if (shop)
    	{
    		this.setVisible(true);
			this.setTitle("Shop");
			this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
			panel.setLayout(new BorderLayout());
			panelsud.setLayout(new BorderLayout());
			panelnorth.setLayout(new BorderLayout());
			panel.add(panelsud, BorderLayout.SOUTH);
			panel.add(panelnorth, BorderLayout.CENTER);
			
			Gcolor.setBackground(Color.GREEN);
			Gcolor.setOpaque(true);
			
			Ycolor.setBackground(Color.YELLOW);
			Ycolor.setOpaque(true);
			
			Rcolor.setBackground(Color.RED);
			Rcolor.setOpaque(true);
			
			JLabel text_shop = new JLabel("SHOP"); 
			text_shop.setForeground(Color.yellow);
			text_shop.setFont(new Font("Arial Black", Font.BOLD, 50));
			panelnorth.add(text_shop, BorderLayout.CENTER);
			
			panelsud.add(Ycolor, BorderLayout.CENTER);
			Ycolor.addActionListener(this);
			panelsud.add(Gcolor, BorderLayout.WEST);
			Gcolor.addActionListener(this);
			panelsud.add(Rcolor, BorderLayout.EAST);
			Rcolor.addActionListener(this);
			panelnorth.setBackground(Color.blue);
			panel.setBackground(Color.blue);
			this.setContentPane(panel);
			this.setSize(400, 400);
			this.setLocationRelativeTo(null);
			panel.updateUI();
    	}
    }

    public void actionPerformed(ActionEvent evt)
    {
    	Object source = evt.getSource();
    	
    	if (source == button_start)
    	{
    		game = true;
    		shop = false;
    		try {
    			mainFrame = new MainFrame();
    		} catch (IOException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    		}
		}
    	else if (source == button_shop)
    	{
    		shop = true;
    		game = false;
    		try {
    			mainFrame = new MainFrame();
    		} catch (IOException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    		}
		}
    	else if (source == button_quit)
    	{
    		this.dispose();
		}
    	else if (source == Gcolor)
    	{
    		try
    		{
    			File file = new File("D:\\save_gd.txt");
            	int keep_money = 0;
                if (file.exists())
                {
                	BufferedReader br = new BufferedReader(new FileReader("D:\\save_gd.txt")); 
                
                	String st; 
                	st = br.readLine();
                	if (st != null && st != "")
                		keep_money = Integer.valueOf(st) - 100;
                }
                if (Integer.valueOf(keep_money) >= 0)
                {
                	FileWriter fw = new FileWriter("D:\\save_gd.txt");
    				fw.write(String.valueOf(keep_money));
    				fw.write(System.getProperty("line.separator") + "green");
        			fw.close();
                }

    		}
    		catch(IOException ioe){}
    	}
    	else if (source == Ycolor)
    	{
    		try
    		{
    			File file = new File("D:\\save_gd.txt");
            	int keep_money = 0;
                if (file.exists())
                {
                	BufferedReader br = new BufferedReader(new FileReader("D:\\save_gd.txt")); 
                
                	String st; 
                	st = br.readLine();
                	if (st != null && st != "")
                		keep_money = Integer.valueOf(st) - 200;
                }
                if (Integer.valueOf(keep_money) >= 0)
                {
                	FileWriter fw = new FileWriter("D:\\save_gd.txt");
    				fw.write(String.valueOf(keep_money));
    				fw.write(System.getProperty("line.separator") + "yellow");
        			fw.close();
                }

    		}
    		catch(IOException ioe){}
    	}
    	else if (source == Rcolor)
    	{
    		try
    		{
    			File file = new File("D:\\save_gd.txt");
            	int keep_money = 0;
                if (file.exists())
                {
                	BufferedReader br = new BufferedReader(new FileReader("D:\\save_gd.txt")); 
                
                	String st; 
                	st = br.readLine();
                	if (st != null && st != "")
                		keep_money = Integer.valueOf(st) - 300;
                }
                if (Integer.valueOf(keep_money) >= 0)
                {
                	FileWriter fw = new FileWriter("D:\\save_gd.txt");
    				fw.write(String.valueOf(keep_money));
    				fw.write(System.getProperty("line.separator") + "red");
        			fw.close();
                }

    		}
    		catch(IOException ioe){}
    	}
    	
    }
    
	public static void main(String[] args) throws IOException 
	{
		mainFrame = new MainFrame();
	}

}